# 使用说明

这是交给 Codex 的开发任务书与输入材料，不是已经开发完成的桌宠应用。

## 文件内容

`CODEX_DESKTOP_PET_PROMPT.md` 是主 Prompt，完整定义本轮需求、动作组格式、随机规则、交互、未来 AI 接口及验收标准。

`AGENTS.md` 是简短项目约定。`reference/character-reference.png` 是用户原始参考截图，未经抠图、拆层或动画绑定。

`examples/custom-action-pack/` 是规范样例，包含自定义点头 motion 和“点头后开心挥手”动作组。它依赖 Codex 后续实现的内置 deepblue-chibi-v1 角色、wave motion、smile 表情和 sparkles 特效；当前任务包本身没有播放器。

`examples/walk_right.group.json` 演示人物步行动画和桌面窗口位移并行，定义归属内置 builtin.deepblue 包。

## 交给 Codex

建议将本文件夹作为新项目工作目录。已有工程时将材料复制进去并合并 AGENTS.md，不要覆盖现有约定或源码。

在该目录打开 Codex，把下面这一段发给它：

```text
请完整读取当前目录的 CODEX_DESKTOP_PET_PROMPT.md 和 AGENTS.md，查看 reference/character-reference.png，然后按任务书在当前目录实现完整可运行的桌宠项目。

重点是：能点击互动的动画角色；动作组通过 JSON 和资源文件新增；普通模式按权重、冷却、条件随机播放；点击和拖动可打断普通动作；动作管理支持导入、预览、重载。

本轮不要开发 AI 模式，不接模型、不调用 API、不加入 API Key 设置，只保留统一控制接口、事件、快照与不可用模式占位。

先列简短实施计划，然后直接逐阶段写代码、运行测试和修复，不要停留在方案或骨架。请用随附 custom-action-pack 验证“不改 TypeScript 就能新增动作”。最后明确报告实际测试结果、素材状态与尚未验证的平台行为。
```

## 素材提醒

原始参考图有背景和界面元素。它用于说明视觉目标，不等于可直接绑定的分层角色资产。任务书要求没有精细素材时先做真正可动的分层演示角色，并保留素材替换能力；不允许虚报原图重绘或拆层结果。

普通模式应完全离线。AI 模式未实现是本轮明确需求，不是故障。
